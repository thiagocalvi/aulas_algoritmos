from dataclasses import dataclass
@dataclass

class Demanda:
    d_bobinas:int = 0
    d_chapas:int = 0
    d_paineis:int = 0
    